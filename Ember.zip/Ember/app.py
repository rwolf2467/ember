from flask import Flask, render_template, request, redirect, session, url_for, jsonify
import os
import requests
import json

app = Flask(__name__)
app.secret_key = os.urandom(24)

DISCORD_CLIENT_ID = '981268814308184084'
DISCORD_CLIENT_SECRET = '2f_evZqSy6KIyOOnHuK1pX2Dej4Rtvfc'
DISCORD_REDIRECT_URI = "http://172.20.10.10:5000/callback"

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/login')
def login():
    return redirect(f"https://discord.com/api/oauth2/authorize?client_id={DISCORD_CLIENT_ID}&redirect_uri={DISCORD_REDIRECT_URI}&response_type=code&scope=email%20identify")

@app.route('/callback')
def callback():
    code = request.args.get('code')
    response = requests.post('https://discord.com/api/oauth2/token', data={
        'client_id': DISCORD_CLIENT_ID,
        'client_secret': DISCORD_CLIENT_SECRET,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': DISCORD_REDIRECT_URI,
        'scope': 'email identify avatar'
    })

    if response.status_code == 200:
        data = response.json()
        user_info = requests.get('https://discord.com/api/users/@me', headers={'Authorization': f'Bearer {data["access_token"]}'})
        user_data = user_info.json()

        session['user_data'] = user_data

        return redirect(url_for('index'))

    return 'Fehler beim Authentifizieren'

@app.route('/get_user_data')
def get_user_data():
    return jsonify(session.get('user_data', {}))

@app.route('/get_posts')
def get_tweets():
    user_data = session.get('user_data', {})
    if user_data.get('id'):
        user_id = user_data['id']
    else:
        user_id = 0

    request = requests.get(url="http://localhost:8001/API/GET/feed",
                           params={"apikey": "1234567890", "keywords": "red", "userid": str(user_id), "length": "10"})
    posts = request.json()

    parsed_posts = []
    for post in posts:
        author_id = post.get("userid")
        author_name = post.get("username")
        avatar = post.get("avatar")
        author_avatar = f'https://cdn.discordapp.com/avatars/{author_id}/{avatar}.png'
        content = post.get("content")
        created = post.get("created")

        parsed_posts.append({
            "author_id": author_id,
            "author_name": author_name,
            "author_avatar": author_avatar,
            "content": content,
            "created": created
        })

    return {'tweets': parsed_posts}

@app.route('/create_post', methods=['POST'])
def create_post():
    user_data = session.get('user_data', {})
    user_id = user_data.get('id', 0)
    
    content = request.form.get('content')
    attachment = request.files.get('attachment')

    if user_data.get("username"):
        username = user_data["username"]
    else:
        username = "UNKNOWN"

    if user_data.get("avatar"):
        avatar = user_data["avatar"]
    else:
        avatar = "UNKNOWN"

    if attachment:
        files = {'attachment': attachment}
        response = requests.post(url="http://localhost:8001/API/SEND/post",
                                 params={"apikey": "1234567890", "userid": user_id, "content": content, "attachements": "", "username": str(username), "avatar": str(avatar)},
                                 files=files)
    else:
        response = requests.post(url="http://localhost:8001/API/SEND/post",
                                 params={"apikey": "1234567890", "userid": user_id, "content": content, "attachements": "", "username": str(username), "avatar": str(avatar)})

    if response.status_code == 200:
        return jsonify(success=True)
    else:
        return jsonify(success=False)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
