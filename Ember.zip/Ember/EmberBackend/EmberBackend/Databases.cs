﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmberBackend
{
    public class Databases
    {
        public static Entities.PostDB postDB = new Entities.PostDB();

    }
}
