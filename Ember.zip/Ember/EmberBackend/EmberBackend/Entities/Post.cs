﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmberBackend.Entities
{
    public class Post
    {
        public ulong userid { get; set; }
        public List<string> attachements { get; set; }

        public string content { get; set; }
        public DateTime created { get; set; }

        public string username { get; set; }

        public string avatar { get; set; }

        public Post(ulong userid, List<string> attachements, string content, DateTime created, string username, string avatar)
        {
            this.userid = userid;
            this.attachements = attachements;
            this.content = content;
            this.created = created;
            this.username = username;
            this.avatar = avatar;
        }
    }
}
