﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace EmberBackend.Entities
{
    public class PostDB
    {
        public List<Post> posts
        {
            get; set;
        }

        public void addPost(Post post)
        {
            Console.WriteLine("Added post");
            if(posts == null)
            {
                posts = new List<Post>();
            }
            posts.Add(post);
        }

        public static string serialize(PostDB db)
        {
            return JsonSerializer.Serialize<PostDB>(db);
        }

        public static PostDB deserialize(string s)
        {
            try
            {
                return JsonSerializer.Deserialize<PostDB>(s);
            }
            catch
            {
                var db = new PostDB();
                Console.WriteLine("Filling DB with test posts");
                db.addPost(new Post(0, new List<string>(), "Systemtest 1", DateTime.Now, "SYSTEM", "none"));
                db.addPost(new Post(1, new List<string>(), "Systemtest 2", DateTime.Now, "SYSTEM", "none"));
                db.addPost(new Post(2, new List<string>(), "Systemtest 3", DateTime.Now, "SYSTEM", "none"));
                return db;
            }
        }


    }
}
