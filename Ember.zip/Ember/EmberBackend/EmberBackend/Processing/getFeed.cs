﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmberBackend.Processing
{
    public class getFeed
    {

        public static Entities.Post[] generateFeed(string keywords, ulong user, int length = 40)
        {

            var list = generateRandomFeed(length);

            return list;
        }


        private static Entities.Post[] generateRandomFeed(int length = 40)
        {
            var random = new Random();

            var feed = new List<Entities.Post>();
            for(int i = 0; i < length; i++)
            {
                try
                {
                    var post = Databases.postDB.posts[random.Next(0, Databases.postDB.posts.Count)];
                    feed.Add(post);
                }
                catch
                {
                    Console.WriteLine("Requested access to post, but index out of range (max {0})", Databases.postDB.posts.Count);
                }
                
            }

            return feed.ToArray();
        }


    }
}
