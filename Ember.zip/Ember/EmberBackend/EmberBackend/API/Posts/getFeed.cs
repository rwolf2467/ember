﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmberBackend.API.Posts
{
    public class getFeed
    {
        public static string generateFeed(Dictionary<string, string> args)
        {
            PureREST.JSONString json = new PureREST.JSONString();
            var feed = Processing.getFeed.generateFeed(args["keywords"], ulong.Parse(args["userid"]), int.Parse(args["length"]));
            return System.Text.Json.JsonSerializer.Serialize(feed);
            /*
            foreach(var post in feed)
            {
                PureREST.JSONString poststring = new PureREST.JSONString();
                poststring.addValue("userid", post.userid);
                poststring.addValue("content", post.content);
                poststring.addValue("datetime", post.created.ToLongTimeString());
                try
                {
                    poststring.addValue("attachements", post.attachements[0]);
                }
                catch
                {

                }
                json.addValue("post", poststring);
            }

            return json.ToString();
            */
        }

    }
}
