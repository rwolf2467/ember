﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmberBackend.API.Posts
{
    public class SavePosts
    {
        public static string savePost(Dictionary<string, string> args)
        {
            try
            {
                var attachements = args["attachements"].Split(' ');
                List<string> att = new List<string>(attachements);
                Entities.Post post = new Entities.Post(uint.Parse(args["userid"]), att, args["content"], DateTime.Now, args["username"], args["avatar"]);
                Databases.postDB.addPost(post);
            }
           catch
            {
                Entities.Post post = new Entities.Post(ulong.Parse(args["userid"]), new List<string>(), args["content"], DateTime.Now, args["username"], args["avatar"]);
                Databases.postDB.addPost(post);

            }





            return "{success: true}";
        }


    }
}
