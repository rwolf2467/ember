﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PureREST;

namespace EmberBackend.API
{
    public class APIManager
    {
        public static PureREST.RESTAPI api = new PureREST.RESTAPI("API");

        public static void startAPI()
        {
            api.registerURL(File.ReadAllText("apiurl.txt"));
            
            
            api.addKey("1234567890", 10, 10, 10f, "1", "Test Key");



            api.addAPIEndPoint("API/SEND/post", Posts.SavePosts.savePost, 0);
            api.addAPIEndPoint("API/GET/feed", Posts.getFeed.generateFeed, 0);

            api.Start();
        }

    }
}
