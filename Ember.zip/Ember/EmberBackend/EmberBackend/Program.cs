﻿// See https://aka.ms/new-console-template for more information


    new Task(() => EmberBackend.API.APIManager.startAPI()).Start();
    EmberBackend.PeriodicTasks.PeriodicTaskManager.start();
while (true)
{
    Console.ReadLine();
}