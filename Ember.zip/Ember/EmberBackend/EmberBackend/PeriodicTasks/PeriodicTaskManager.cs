﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmberBackend.PeriodicTasks
{
    public class PeriodicTaskManager
    {

        public static void start()
        {
            Console.WriteLine("Loading databases");
            Console.WriteLine("Fetching Post Database...");
            string postdbJSON = File.ReadAllText(@".\DB\posts.db");
            Console.WriteLine("Fetched Post Database ({0}) bytes", postdbJSON.Length);
            Console.WriteLine("Reconstructing Database...");
            Databases.postDB = Entities.PostDB.deserialize(postdbJSON);
            
            float dataloss = (1 - (Entities.PostDB.serialize(Databases.postDB).Length / (postdbJSON.Length+1))) * 100;
            Console.WriteLine("Data loss: " + dataloss + "%");




            RunInBackground(TimeSpan.FromSeconds(5), () => saveDB());
        }

        public static async Task RunInBackground(TimeSpan timespan, Action action)
        {
            var periodicTimer = new PeriodicTimer(timespan);
            while (await periodicTimer.WaitForNextTickAsync())
            {

                action();
            }
        }

        private static async Task saveDB()
        {
            Console.WriteLine("Saving DB");
            File.WriteAllText(@".\DB\posts.db", Entities.PostDB.serialize(Databases.postDB));
        }
    }
}
